<?php $__env->startSection('content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">

        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>Edit Students</h4>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active"><a href="edit-Teacher.html">Students</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0)">Edit Students</a></li>
                </ol>
            </div>
        </div>

        <div class="row">
            <div class="col-xl-12 col-xxl-12 col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title">Basic Info</h5>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('students.update',$data->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Student ID <span class="text-danger">*Not Editable*</span></label>
                                        <input type="text" name="fName" class="form-control" value="<?php echo e($data->studentId); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Class Name <span class="text-danger">*Not Editable*</span></label>
                                        <input type="text" name="classname" class="form-control" value="<?php echo e($data->classname); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Student Name English</label>
                                        <input type="text" name="studentNameEn" class="form-control" value="<?php echo e($data->studentNameEn); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Student Name Bangla</label>
                                        <input type="text" name="studentNameBn" class="form-control" value="<?php echo e($data->studentNameBn); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Mother Mobile No</label>
                                        <input type="text" name="motherMobile" class="form-control" value="<?php echo e($data->motherMobile); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Email</label>
                                        <input type="text" name="email" class="form-control" value="<?php echo e($data->email); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Date Of Birth</label>
                                        <input type="date" name="dob" class="form-control" value="<?php echo e($data->dob); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Gender</label>
                                        <input type="text" name="gender" class="form-control" value="<?php echo e($data->gender); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Blood Group</label>
                                        <input type="text" name="bloodGroup" class="form-control" value="<?php echo e($data->bloodGroup); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Birth Certificate</label>
                                        <input type="text" name="birthCertificate" class="form-control" value="<?php echo e($data->birthCertificate); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Father Name English</label>
                                        <input type="text" name="fatherNameEn" class="form-control" value="<?php echo e($data->fatherNameEn); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Father Name Bangla</label>
                                        <input type="text" name="fatherNameBn" class="form-control" value="<?php echo e($data->fatherNameBn); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Mother Name English</label>
                                        <input type="text" name="motherNameEn" class="form-control" value="<?php echo e($data->motherNameEn); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Mother Name Bangla</label>
                                        <input type="text" name="motherNameBn" class="form-control" value="<?php echo e($data->motherNameBn); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Father's Mobile</label>
                                        <input type="text" name="fatherMobile" class="form-control" value="<?php echo e($data->fatherMobile); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">NID</label>
                                        <input type="text" name="nid" class="form-control" value="<?php echo e($data->nid); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Village Present</label>
                                        <input type="text" name="villagePreset" class="form-control" value="<?php echo e($data->villagePreset); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Post Present</label>
                                        <input type="text" name="postPreset" class="form-control" value="<?php echo e($data->postPreset); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Thana Present</label>
                                        <input type="text" name="thanaPreset" class="form-control" value="<?php echo e($data->thanaPreset); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">District Present</label>
                                        <input type="text" name="distPreset" class="form-control" value="<?php echo e($data->distPreset); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Village Permanent</label>
                                        <input type="text" name="villagePermanent" class="form-control" value="<?php echo e($data->villagePermanent); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Post Permanent</label>
                                        <input type="text" name="postPermanent" class="form-control" value="<?php echo e($data->postPermanent); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Thana Permanent</label>
                                        <input type="text" name="thanaPermanent" class="form-control" value="<?php echo e($data->thanaPermanent); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">District Permanent</label>
                                        <input type="text" name="distPermanent" class="form-control" value="<?php echo e($data->distPermanent); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Session <span class="text-danger">*Not Editable*</span></label>
                                        <input type="text" name="session" class="form-control" value="<?php echo e($data->session); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Amount <span class="text-danger">*Not Editable*</span></label>
                                        <input type="text" name="amount" class="form-control" value="<?php echo e($data->amount); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Payment Method <span class="text-danger">*Not Editable*</span></label>
                                        <input type="text" name="paymentmethod" class="form-control" value="<?php echo e($data->paymentmethod); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Payment Number <span class="text-danger">*Not Editable*</span></label>
                                        <input type="text" name="pyamentnumber" class="form-control" value="<?php echo e($data->pyamentnumber); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Trxid <span class="text-danger">*Not Editable*</span></label>
                                        <input type="text" name="trxid" class="form-control" value="<?php echo e($data->trxid); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Admission Date <span class="text-danger">*Not Editable*</span></label>
                                        <input type="date" name="admissiondate" class="form-control" value="<?php echo e($data->admissiondate); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Invoice Number <span class="text-danger">*Not Editable*</span></label>
                                        <input type="text" name="mobile" class="form-control" value="<?php echo e($data->invoice); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-lg-12 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Profile Image</label>
                                        <img class="" width="135"
                                            src="<?php echo e((!empty($data->studentImage))?url('admin/students/'.$data->studentImage): url('admin/images/profile/small/pic3.jpg')); ?>" alt="">
                                    </div>
                                </div>
                                <div class="col-lg-12 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Change Image</label>
                                        <input type="file" name="studentImage" id="">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-6 col-sm-12">
                                <div class="form-group mb-4">
                                    <label class="form-label">Status</label>
                                    <select name="status" class="form-control" required>
                                        <option value="Fess Type">Status Type</option>
                                        <option
                                            value="0"
                                            <?php echo e($data->status == '0' ? 'selected' : ''); ?>>
                                            Pending
                                        </option>
                                        <option
                                            value="1"
                                            <?php echo e($data->status == '1' ? 'selected' : ''); ?>>
                                            Paid
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <button type="submit" class="btn btn-success">Update</button>
                            </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>
</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coaching-management-system-by-laravel\resources\views/pages/admin/students/editStudent.blade.php ENDPATH**/ ?>