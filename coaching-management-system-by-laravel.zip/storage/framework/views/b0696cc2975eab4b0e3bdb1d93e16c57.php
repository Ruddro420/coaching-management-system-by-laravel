<?php $__env->startSection('content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">

        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>Edit Students</h4>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active"><a href="edit-Teacher.html">Students</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0)">Edit Students</a></li>
                </ol>
            </div>
        </div>

        <div class="row">
            <div class="col-xl-12 col-xxl-12 col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title">Basic Info</h5>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('students.update',$data->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Student ID</label>
                                        <input type="text" name="fName" class="form-control" value="<?php echo e($data->studentId); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Class Name</label>
                                        <input type="text" name="fName" class="form-control" value="<?php echo e($data->classname); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-lg-12 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Student Name</label>
                                        <input type="text" name="lName" class="form-control" value="<?php echo e($data->studentNameEn); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Father's Name</label>
                                        <input name="rDate" class="datepicker-default form-control"
                                            type="text" value="<?php echo e($data->fatherNameEn); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Father Mobile Number</label>
                                        <input type="text" name="mobile" class="form-control" value="<?php echo e($data->fatherMobile); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Payment Method</label>
                                        <input type="text" name="mobile" class="form-control" value="<?php echo e($data->paymentmethod); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Payment Mobile Number</label>
                                        <input type="text" name="mobile" class="form-control" value="<?php echo e($data->pyamentnumber); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Transection Id</label>
                                        <input type="text" name="mobile" class="form-control" value="<?php echo e($data->trxid); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Invoice Number</label>
                                        <input type="text" name="mobile" class="form-control" value="<?php echo e($data->invoice); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Payment Amount</label>
                                        <input type="text" name="mobile" class="form-control" value="<?php echo e($data->amount); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Admission Date</label>
                                        <input type="text" name="mobile" class="form-control" value="<?php echo e($data->admissiondate); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-lg-12 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Profile Image</label>
                                        <img class="" width="135"
                                            src="<?php echo e((!empty($data->studentImage))?url('admin/students/'.$data->studentImage): url('admin/images/profile/small/pic3.jpg')); ?>" alt="">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group mb-4">
                                        <label class="form-label">Status</label>
                                        <select name="status" class="form-control" required>
                                            <option value="Fess Type">Status Type</option>
                                            <option
                                                value="0"
                                                <?php echo e($data->status == '0' ? 'selected' : ''); ?>>
                                                Pending
                                            </option>
                                            <option
                                                value="1"
                                                <?php echo e($data->status == '1' ? 'selected' : ''); ?>>
                                                Paid
                                            </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <button type="submit" class="btn btn-success">Update</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coaching-management-system-by-laravel\resources\views/pages/admin/students/editStudent.blade.php ENDPATH**/ ?>