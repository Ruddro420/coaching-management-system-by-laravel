<?php $__env->startSection('content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">

        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>Fees Collection</h4>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0);">Fees</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0);">Fees Collection</a></li>
                </ol>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Fees Collection</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="example4" class="display" style="min-width: 845px">
                                <thead>
                                    <tr>
                                        <th>Student ID</th>
                                        <th>Name</th>
                                        <th>Class</th>
                                        <th>Method</th>
                                        <th>Number</th>
                                        <th>TrxId</th>
                                        <th>Date</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($value->roll); ?></td>
                                        <td><?php echo e($value->stdName); ?></td>
                                        <td><?php echo e($value->course); ?></td>
                                        <td><?php echo e($value->pType); ?></td>
                                        <td><?php echo e($value->pRef); ?></td>
                                        <td><?php echo e($value->pDetails); ?></td>
                                        <td><?php echo e($value->cDate); ?></td>
                                        <td><strong><?php echo e($value->amount); ?> ৳</strong></td>
                                        <td>
                                            <strong>
                                                <?php if($value->status == 0): ?>
                                                Pending
                                                <?php elseif($value->status == 1): ?>
                                                Paid
                                                <?php else: ?>
                                                Unknown
                                                <?php endif; ?>
                                            </strong>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('fees.edit' ,$value->id)); ?>" class="btn btn-sm btn-primary"><i
                                                    class="la la-pencil"></i></a>
                                            <a href="<?php echo e(route('fees.delete' ,$value->id)); ?>" id="delete" class="btn btn-sm btn-danger"><i
                                                    class="la la-trash-o"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coaching-management-system-by-laravel\resources\views/pages/admin/fees/viewFees.blade.php ENDPATH**/ ?>