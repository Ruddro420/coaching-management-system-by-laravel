<?php $__env->startSection('content'); ?>
<style>
    .invoice-content {
        padding: 20px;
        text-align: center;
    }

    .invoice-content h1 {
        font-size: 35px;
        font-weight: 900;
        margin-bottom: 10px;
    }
</style>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">

        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>Fees Receipt</h4>
                </div>
                <div class="mt-3">
                    <form action="<?php echo e(route('invoice.search')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div class="form-group">
                                    <label class="form-label">Roll No.</label>
                                    <input placeholder="Enter roll number" name="roll" type="number" class="form-control" required>
                                    <button class="btn btn-info mt-3">Fees Report</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Fees</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0);">Fees Receipt</a></li>
                </ol>
            </div>
        </div>


        <?php if(count($data) > 0): ?>
        <div class="row">
            <div class="col-lg-12">

                <div class="card mt-3" id="content-to-print">
                    <div class="invoice-content">
                        <h1>Fees Report</h1>
                        <b>
                            <h5>মেধা বিকাশ শিশু নিকেতন এন্ড কুরআন একাডেমি</h5>
                        </b>
                        <b>Email: mbsn2918@gmail.com</b> <br>
                        <b>Phone: +880 1717-084442</b><br>
                    </div>
                    <div class="table-responsive-sm mt-5">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th class="center">Roll No</th>
                                    <th>Class</th>
                                    <th>Payment Type</th>
                                    <th class="right">Date</th>
                                    <th class="right">Status</th>
                                    <th class="right">Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="center"><?php echo e($item->roll); ?></td>
                                    <td class="left strong"><?php echo e($item->course); ?></td>
                                    <td class="left"><?php echo e($item->pType); ?></td>
                                    <td class="right"><?php echo e($item->cDate); ?></td>
                                    <td class="right"><strong>
                                            <?php if($item->status == 0): ?>
                                            Pending
                                            <?php elseif($item->status == 1): ?>
                                            Paid
                                            <?php else: ?>
                                            Unknown
                                            <?php endif; ?>
                                        </strong></td>
                                    <td class="right"><?php echo e($item->amount); ?> ৳</td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    
        </div>
        <div class="row">
            <div class="col-lg-12 text-right">
                <button id="print-button" class="btn btn-info bg-info" type="button"> <i class="fa fa-print"></i> Print </button>
            </div>
        </div>
    </div>
</div>
</div>
<?php else: ?>

<?php endif; ?>
</div>
</div>


<script>
    document.getElementById("print-button").addEventListener("click", function() {
        var contentToPrint = document.getElementById("content-to-print").innerHTML;
        var printWindow = window.open("", "_blank");

        printWindow.document.open();
        printWindow.document.write('<html><head><title>Print</title>');
        printWindow.document.write('</head><body>');
        printWindow.document.write(contentToPrint);
        printWindow.document.write('</body></html>');

        // Include your CSS stylesheet to maintain styling
        printWindow.document.write(`<style>
            .invoice-content{
        padding: 20px;
        text-align: center;
    }
    .invoice-content h1{
        font-size: 35px;
        font-weight: 900;
        margin-bottom: 10px;
    }
    td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}
</style>`);

        printWindow.document.close();

        // Delay the print function to allow styles to load
        printWindow.setTimeout(function() {
            printWindow.print();
            printWindow.close();
        }, 500); // Adjust the delay time if needed
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coaching-management-system-by-laravel\resources\views/pages/admin/fees/feesInvoice.blade.php ENDPATH**/ ?>